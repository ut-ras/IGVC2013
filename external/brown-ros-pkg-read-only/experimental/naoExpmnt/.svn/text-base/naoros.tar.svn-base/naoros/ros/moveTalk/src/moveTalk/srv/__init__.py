from _QVGA import *
