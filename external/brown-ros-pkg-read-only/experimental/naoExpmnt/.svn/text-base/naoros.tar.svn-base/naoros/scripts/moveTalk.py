#!/usr/bin/python
import sys
sys.path.append("/opt/naoqi/extern/python/aldebaran")
sys.path.append("../pythonModules")

import roslib
roslib.load_manifest('moveTalk')
import rospy

from std_msgs.msg import String
from moveTalk.msg import Head
from moveTalk.msg import Motion
from moveTalk.srv import *

import naoqi
from naoqi import ALProxy

from stand import stand

from threading import Thread

def handleSpeech(data):
	tts.say(data.data)

def handleHead(data):
	x = data.x
	y = data.y
	xAngle = 1.4*(x/256.)-.7
	yAngle = 1.4*(y/256.)-.7

	try:
		motion.setAngle("HeadYaw", -xAngle)
		motion.setAngle("HeadPitch", yAngle)
	except:
		print "problem"

def handleMotion(data):
	if (motion2.getTaskList() != "None"):
		return
	steps = 95

	if (data.stand):
		stand(motion2)
		return
	elif(data.forward):
		motion2.addWalkStraight(.15,steps)
	elif(data.left):
		motion2.addTurn(.34,steps)
	elif(data.right):
		motion2.addTurn(-.34,steps)
	
	if (data.forward or data.left or data.right):
		motion2.walk()

def motListener():
	rospy.Subscriber("motion", Motion, handleMotion, queue_size=1)

def strListener():
	rospy.Subscriber("speech", String, handleSpeech)
	#rospy.Subscriber("speech", String, handleSpeech, queue_size=1)

def hdListener():
	rospy.Subscriber("head", Head, handleHead, queue_size=1)

def handle_qvga(req):
	img = cameraProxy.getImageRemote(eyes)
	img = tuple(map(lambda c: ord(c),img[6]))
	return QVGAResponse(img)

if __name__ == '__main__':
	tts = ALProxy("ALTextToSpeech","127.0.0.1",9559)
	tts.setSystemVolume(85)
	motion = ALProxy("ALMotion","127.0.0.1",9559)
	motion2 = ALProxy("ALMotion","127.0.0.1",9559)
	cameraProxy = ALProxy("ALVideoDevice","127.0.0.1",9559)

	rospy.init_node('listener', anonymous=True)
	hdListener()
	strListener()
	motListener()

	#motion.setJointStiffness("HeadYaw",1.0)
	#motion.setJointStiffness("HeadPitch",1.0)
	motion.setBodyStiffness(1.0)

	eyes = cameraProxy.subscribe("eyes", 0, 11, 30)
	rospy.Service('qvga', QVGA, handle_qvga)

	try:
		print "service running"
		rospy.spin()
	except:
		print "stopping"
	finally:
		cameraProxy.unsubscribe(eyes)
		motion.setBodyStiffness(0.0)
